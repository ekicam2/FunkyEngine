#pragma once

namespace Funky
{
	namespace Math
	{
		struct LinearColor
		{
			float r, g, b, a;

			LinearColor()
				: LinearColor(0.0f, 0.0f, 0.0f, 0.0f)
			{

			}

			LinearColor(float const & r, float const & g, float const & b, float const & a)
				: r(r)
				, g(g)
				, b(b)
				, a(a)
			{

			}

			LinearColor& operator=(LinearColor const & New)
			{
				r = New.r;
				g = New.g;
				b = New.b;
				a = New.a;

				return *this;
			}
		};
	}
}