#pragma once

#include <cmath>

namespace Funky
{
	namespace Math
	{
		constexpr double PI = 3.14159265358979323846264338327950288419716939937510;

		template <typename T>
		constexpr T ToDeg(T Theta) { return (Theta * T(180.0) / T(PI)); }

		template <typename T>
		constexpr T ToRad(T Theta) { return (Theta * T(PI) / T(180.0)); }

		template <typename T>
		constexpr T Abs(T InValue)
		{
			return abs(InValue);
		}
	}
}
