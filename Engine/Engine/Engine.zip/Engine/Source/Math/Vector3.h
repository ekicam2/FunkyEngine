#pragma once

#include "Globals.h"

namespace Funky
{
	namespace Math
	{
		template <typename T>
		struct Vector3D
		{
			T x, y, z;

			Vector3D(T const & x, T const & y, T const & z) : x(x), y(y), z(z) { }

			Vector3D operator+(Vector3D const & Rhs) const
			{
				return { x + Rhs.x, y + Rhs.y, z + Rhs.z };
			}

			void operator+=(Vector3D const & Rhs)
			{
				x += Rhs.x;
				y += Rhs.y;
				z += Rhs.z;
			}

			Vector3D operator-(Vector3D const & Rhs) const
			{
				return { x - Rhs.x, y - Rhs.y, z - Rhs.z };
			}

			Vector3D operator*(T Scalar) const
			{
				return { x * Scalar, y * Scalar, z * Scalar };
			}

			Vector3D& operator=(Vector3D const & New)
			{
				x = New.x;
				y = New.y;
				z = New.z;

				return *this;
			}

			Vector3D& operator=(T const New[3])
			{
				x = New[0];
				y = New[1];
				z = New[2];

				return *this;
			}

			Vector3D RotateX(T Theta) const
			{
				const float CosTheta = cos(ToRad(Theta));
				const float SinTheta = sin(ToRad(Theta));

				return {
					x,
					(y * CosTheta) - (z * SinTheta),
					(y * SinTheta) + (z * CosTheta)
				};
			}

			Vector3D RotateY(T Theta) const
			{
				const float CosTheta = cos(ToRad(Theta));
				const float SinTheta = sin(ToRad(Theta));

				return {
					(x * CosTheta) + (z * SinTheta),
					y, 
					-(x * SinTheta) + (z * CosTheta)
				};
			}

			Vector3D RotateZ(T Theta) const
			{
				const float CosTheta = cos(ToRad(Theta));
				const float SinTheta = sin(ToRad(Theta));
				
				return {
					(x * CosTheta) - (y * SinTheta),
					(x * SinTheta) + (y * CosTheta),
					z
				};
			}

			T Dot(Vector3D const & Rhs) const
			{
				return  x * Rhs.x + y * Rhs.y + z * Rhs.z;
			}

			T Cross(Vector3D const & Rhs) const
			{
				return  {
					y * Rhs.z - z * Rhs.y,
					z * Rhs.x - x * Rhs.z,
					x * Rhs.y - y * Rhs.x 
				};
			}

			T GetLength() const
			{
				return sqrt(x * x + y * y + z * z);
			}

			Vector3D Normalize() const
			{
				const T Length = GetLength();

				return {
					x / Length,
					y / Length,
					z / Length
				};
			}
		};
	
		typedef Vector3D<float> Vector3f;
		typedef Vector3D<double> Vector3d;
	}
}