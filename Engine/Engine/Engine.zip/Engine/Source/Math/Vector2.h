#pragma once

#pragma once

namespace Funky
{
	namespace Math
	{
		template <typename T>
		struct Vector2D
		{
			T x, y;

			Vector2D(T x, T y) : x(x), y(y) { }

			Vector2D operator+(Vector2D const & Rhs)
			{
				return { x + Rhs.x, y + Rhs.y};
			}

			void operator+=(Vector2D const & Rhs)
			{
				x += Rhs.x;
				y += Rhs.y;
			}

			Vector2D operator-(Vector2D const & Rhs)
			{
				return { x - Rhs.x, y - Rhs.y };
			}

			Vector2D operator*(T Scalar)
			{
				return { x * Scalar, y * Scalar };
			}

			Vector2D& operator=(Vector2D const & New)
			{
				x = New.x;
				y = New.y;

				return *this;
			}

			T Dot(Vector2D const & Rhs)
			{
				return  x * Rhs.x + y * Rhs.y;
			}
		};

		typedef Vector2D<float> Vector2f;
		typedef Vector2D<double> Vector2d;
		typedef Vector2D<unsigned> Vector2u;
	}
}