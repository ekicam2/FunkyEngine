#define TINYOBJLOADER_IMPLEMENTATION
#include "3rd/TinyObjectLoader.h"