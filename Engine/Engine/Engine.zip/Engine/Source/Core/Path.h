#pragma once

#include <string>

typedef std::string path;