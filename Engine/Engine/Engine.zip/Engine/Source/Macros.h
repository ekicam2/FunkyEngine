#pragma once

#ifdef _DEBUG
#define FORCEINLINE_DEBUGGABLE
#else
#define FORCEINLINE_DEBUGGABLE __forceinline
#endif

#ifdef FORCEINLINE
#undef FORCEINLINE
#endif

#define FORCEINLINE __forceinline
