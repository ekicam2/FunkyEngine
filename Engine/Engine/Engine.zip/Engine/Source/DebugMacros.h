#pragma once

#include "LogMacros.h"

#include <assert.h>
#define WINDOWS_LEAN_AND_MEAN
#include "Windows.h"
#include <stdio.h>

#ifdef _DEBUG

#if !UNICODE
#error "UNICODE switch has to be turned on, Properties -> General -> Character Set"
#endif

namespace {
	template <typename T>
	bool OnceOnly(T const &)
	{
		static bool returner = true;
		if (returner) { returner = 0; return true; }
		return false;
	}

	bool ShowAssertionBox(wchar_t const * pMsg, wchar_t const * const pCond, wchar_t const * const pFile, int iLine)
	{
		wchar_t pRealMsg[512];
		wcscpy_s(pRealMsg, 512, L"Assertion failed: ");
		wcscat_s(pRealMsg, 512, pCond);
		wcscat_s(pRealMsg, 512, L"  \n");
		wcscat_s(pRealMsg, 512, pMsg);
		wcscat_s(pRealMsg, 512, L"  \n");
		wcscat_s(pRealMsg, 512, pFile);
		wcscat_s(pRealMsg, L":");
		wchar_t pRealLine[5];
		swprintf(pRealLine, 5, L"%d", iLine);
		wcscat_s(pRealMsg, pRealLine);

		int answear = MessageBox(0, pRealMsg, L"CRASHED", MB_ABORTRETRYIGNORE | MB_SYSTEMMODAL);
		switch (answear)
		{
			case IDABORT:
				exit(-1);
				break;

			case IDRETRY:
				return true;
				break;

			case IDIGNORE:
			default:
				return false;
				break;
		}
	}
}

#ifdef UNICODE
#define _TEXTIFY_(X) L#X
#else
#define _TEXTIFY_(X) X
#endif
#define _TEXTIFY(X) _TEXTIFY_(X)

#define _CONCAT2_(First, Second) First ## Second
#define CONCAT2(First, Second) _CONCAT2_(First, Second)

#define ASSERT_ONCE(condition, msg) if(!(condition) && OnceOnly([]{})) { if(ShowAssertionBox(msg, _TEXTIFY_(condition), _TEXTIFY(__FILE__), __LINE__)) __debugbreak(); }
#define ASSERT(condition, msg) if(!(condition)) { LOG_ERROR(msg); if(ShowAssertionBox(msg, _TEXTIFY_(condition), _TEXTIFY(__FILE__), __LINE__)) __debugbreak(); }

#define DEATH_PATH(...) ASSERT(false, L"death path reached")
#define BREAK(...) __debugbreak()

#define DEF_DEBUG_SCOPE_TIMER(TimerName) ScopeTimer<Timer::EResolution::Mills> CONCAT2(ScopeTimer, __LINE__)(TimerName)
#define DEF_DEBUG_SCOPE_TIMER_MICRO(TimerName) ScopeTimer<Timer::EResolution::Micro> CONCAT2(ScopeTimer, __LINE__)(TimerName)
#define DEF_DEBUG_SCOPE_TIMER_SEC(TimerName) ScopeTimer<Timer::EResolution::Sec> CONCAT2(ScopeTimer, __LINE__)(TimerName)

#else

#define DEATH_PATH _assume(false)
#define ASSERT_ONCE(...)
#define ASSERT(...)
#define TRY(expression) expression
#define BREAK(...) 
#define DEF_DEBUG_SCOPE_TIMER(...)


#endif