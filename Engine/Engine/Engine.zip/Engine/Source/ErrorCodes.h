#pragma once

namespace ErrorCode
{
	constexpr int UNKNOWN							= 0xffffffff;

	// 0xff = 256 i think its enough for window associated error codes
	constexpr int WINDOW_REGISTRATION_CLASS_ERROR	= ErrorCode::UNKNOWN - 1;
	constexpr int WINDOW_CREATION_ERROR				= 0xfffffffe;
	
	constexpr int DIRECTX_DEVICE_CREATION_ERROR		= 0xfffff00;
	constexpr int DIRECTX_BUFFER_ERROR				= 0xffffeff;
	constexpr int RENDER_TARGET_CREATION_ERROR		= 0xffffefe;
	constexpr int DEPTH_STENCIL_CREATION_ERROR		= 0xffffefd;
	//constexpr int WINDOW_CREATION_ERROR				= 0xfffffff9;
	//constexpr int WINDOW_CREATION_ERROR				= 0xfffffff8;

}