#pragma once

#include "Math/Vector3.h"

namespace Funky
{
	class Camera
	{
	public:
		Camera(float AspectRatio, float FOV = 90.0f, float Near = 0.01f, float Far = 100.0f)
			: m_mProjection(DirectX::XMMatrixPerspectiveFovLH(DirectX::XMConvertToRadians(FOV), AspectRatio, Near, Far))
			, Position(0.0f, 0.0f, 0.0f)
			, Rotation(0.0f, 0.0f, 0.0f)
			, LookAt(0.0f, 0.0f, 100.f)
			, Up(0.0f, 1.0f, 0.0f)
		{
			RecalculateView();
		}

		void MakePerepective(float AspectRatio, float FOV = 90.0f, float Near = 0.01f, float Far = 100.0f)
		{
			m_mProjection = DirectX::XMMatrixPerspectiveFovLH(DirectX::XMConvertToRadians(FOV), AspectRatio, Near, Far);
			RecalculateView();
		}

		void MakeOrtho(float Width, float Height, float Near = 0.01f, float Far = 100.0f)
		{
			m_mProjection = DirectX::XMMatrixOrthographicLH(Width, Height, Near, Far);
			RecalculateView();
		}

		FORCEINLINE DirectX::XMMATRIX const & GetProjection() const { return m_mProjection; }

		FORCEINLINE DirectX::XMMATRIX const & GetView()
		{ 
			if (bViewDirty) 
				RecalculateView(); 
			return m_mView; 
		}
	
		FORCEINLINE Funky::Math::Vector3f const & GetLookat() { return LookAt; }

		FORCEINLINE Funky::Math::Vector3f const & GetPosition() { return Position; }
		
		void Translate(Funky::Math::Vector3f const & vTranslation) 
		{ 
			Funky::Math::Vector3f Temp = vTranslation;

			Temp = Temp.RotateX(Rotation.x);
			Temp = Temp.RotateY(Rotation.y);
			Temp = Temp.RotateZ(Rotation.z);

			Position += Temp;
			bViewDirty = true; 
		}
		void Rotate(Funky::Math::Vector3f const & vRotation) { Rotation += vRotation; bViewDirty = true; }

		/* @vAxisToClamp: {0.0f, 1.0f, 0.0f}, {0.0f, 1.0f, 1.0f} etc. */
		void RotateClamped(Funky::Math::Vector3f const & vRotation, Funky::Math::Vector3f const & vAxisToClamp, Funky::Math::Vector3f const & vAxisMax) 
		{ 
			Rotation += vRotation; 
			
			if (1.0f == vAxisToClamp.x && Funky::Math::Abs(Rotation.x) > vAxisMax.x)
				Rotation.x = vAxisMax.x * (Rotation.x / Funky::Math::Abs(Rotation.x));

			if (1.0f == vAxisToClamp.y && Funky::Math::Abs(Rotation.y) > vAxisMax.y)
				Rotation.y = vAxisMax.y * (Rotation.y / Funky::Math::Abs(Rotation.y));

			if (1.0f == vAxisToClamp.z && Funky::Math::Abs(Rotation.z) > vAxisMax.z)
				Rotation.z = vAxisMax.z * (Rotation.z / Funky::Math::Abs(Rotation.z));

			bViewDirty = true; 
		}

	private:
		void RecalculateView()
		{
			Funky::Math::Vector3f Forward(0.0f, 0.0f, 100.f);

			Forward = Forward.RotateX(Rotation.x);
			Forward = Forward.RotateY(Rotation.y);
			Forward = Forward.RotateZ(Rotation.z);

			LookAt = Position + Forward;

			m_mView = DirectX::XMMatrixLookAtLH(
				DirectX::XMVectorSet(Position.x, Position.y, Position.z, 0.0f),
				DirectX::XMVectorSet(LookAt.x, LookAt.y, LookAt.z, 0.0f),
				DirectX::XMVectorSet(Up.x, Up.y, Up.z, 0.0f)
			);

			bViewDirty = false;
		}

		bool bViewDirty = false;

		Funky::Math::Vector3f Position;
		Funky::Math::Vector3f Rotation;
		Funky::Math::Vector3f LookAt;
		const Funky::Math::Vector3f Up;

		DirectX::XMMATRIX m_mProjection;
	
		DirectX::XMMATRIX m_mView = DirectX::XMMatrixLookAtLH(
			DirectX::XMVectorSet(Position.x, Position.y, Position.z, 0.0f),
			DirectX::XMVectorSet(LookAt.x, LookAt.y, LookAt.z, 0.0f),
			DirectX::XMVectorSet(Up.x, Up.y, Up.z, 0.0f)
		);
	};
}

