#pragma once

//TODO: SIMD implementation